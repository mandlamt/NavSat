﻿using NavSat.Core.Abstrations.Models;
using NavSat.Core.ApiClients.Dtos;
using AutoMapper;


namespace NavSat.Core.ApiClients.Mappers {
    public interface SatOrbitMapperProfile {
        SatelliteOrbit Map(SatAlmanac dto);
    }
}




//public class SatOrbitMapperProfile : Profile
//{
//    public SatOrbitMapperProfile()
//    {
//        CreateMap<SatAlmanac, SatelliteOrbit>();
//    }
//}