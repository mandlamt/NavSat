using Microsoft.VisualStudio.TestTools.UnitTesting;
using NavSat.Core.Abstrations.ApiClients;
using NavSat.Core.Abstrations.Models;
using NavSat.Core.Abstrations.Services;
using NavSat.Core.ApiClients;
using NavSat.Core.ApiClients.Mappers;
using NavSat.Core.Services;
using System;
using System.Linq;
using System.Threading.Tasks;
namespace NavSat.Core.Tests
{
    [TestClass]
    public class IntegrationTests
    {
        [TestMethod]
        public async Task OrbitApiClient_SmokeTest()
        {
            // Arrange
            var client = CreateOrbitApiClient();
            // Act
            var orbits = await client.GetOrbitsAsAtAsync(DateTimeOffset.UtcNow);
            // Assert
            Assert.IsNotNull(orbits);
        }
        [TestMethod]
        public async Task SatellitePathService_SmokeTest()
        {
            // Arrange
            var service = CreateSatellitePathService();
            var capeTown = new GeoCoordinate()
            {
                Latitude = -33.9249,
                Longitude = 18.4241,
                Altitude = 100
            };
            var start = DateTimeOffset.UtcNow.AddMinutes(-10);
            var mid = DateTimeOffset.UtcNow;
            var end = DateTimeOffset.UtcNow.AddMinutes(10);
            var times = new[] { start, mid, end };
            // Act
            var result = await service.GetAsSeenFromDuringAsync(capeTown, times);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any(s => s.Path.Count() == times.Count()));
        }
        #region Test Factory
        private OrbitApiClient CreateOrbitApiClient(IOrbitApiClientConfig config = null, SatOrbitMapperProfile mapper = null)
        {
            config = config ?? new TestConfig();
            mapper = mapper ?? new SatOrbitMapper();
            return new OrbitApiClient(config, mapper);
        }
        private ConstellationService CreateConstellationService()
        {
            return new ConstellationService();
        }
        private SatelliteService CreateSatelliteService(IConstellationService constellationService = null)
        {
            constellationService = constellationService ?? CreateConstellationService();
            return new SatelliteService(constellationService);
        }
        private SatellitePathService CreateSatellitePathService(IGeoMath geoMath = null, ISatMath satMath = null, IOrbitApiClient orbitApiClient = null, ISatelliteService satService = null)
        {
            geoMath = geoMath ?? new GeoMath();
            satMath = satMath ?? new SatMath();
            orbitApiClient = orbitApiClient ?? CreateOrbitApiClient();
            satService = satService ?? CreateSatelliteService();
            return new SatellitePathService(geoMath, satMath, orbitApiClient, satService);
        }
        private class TestConfig : IOrbitApiClientConfig
        {
            public string BaseUrl => "https://www.gnssplanning.com/api/almanac";
        }
        #endregion

    }
}
