  # error_handler.R

library(plumber)

handler_error <- function(req, res, err){
  res$status <- 500
  list(error = "Custom Error Message")
}

pr <- plumb("api")

pr <- pr %>% 
  pr_get("/error", function() 1 + "1") %>% 
  pr_set_error(handler_error) %>% 
  pr_run()