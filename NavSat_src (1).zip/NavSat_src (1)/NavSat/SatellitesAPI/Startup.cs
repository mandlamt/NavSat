using Microsoft.AspNetCore.Mvc;
using NavSat.Core.Services;
using NavSat.Core;
using NavSat.Core.Abstrations.Services;
using NavSat.Core.Tests;
using NavSat.Core.Abstrations.Models;
using Microsoft.OpenApi.Models;


[Route("api/[controller]")]
[ApiController]
public class Startup : ControllerBase
{
    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        app.UseSwagger();
        app.UseSwaggerUI(c =>
        {
            c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
        });
    }

    public void ConfigureServices(IServiceCollection services)
    {
        services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo { Title = "My API", Version = "v1" });
        });
    }


    
}