using Microsoft.AspNetCore.Mvc;
using NavSat.Core.Services;
using NavSat.Core;
using NavSat.Core.Abstrations.Services;
using NavSat.Core.Tests;
using NavSat.Core.Abstrations.Models;


[Route("api/[controller]")]
[ApiController]
public class SatellitePathController : ControllerBase
{
    private readonly  ISatellitePathService _satellitePathService;

    public SatellitePathController(ISatellitePathService satellitePathService)
    {
        _satellitePathService = satellitePathService;
    }

    // Example endpoint for Get Satellite Locations

    // Add other endpoints for other service methods
}