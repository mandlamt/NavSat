using Microsoft.AspNetCore.Mvc;
using NavSat.Core.Services;
using NavSat.Core;
using NavSat.Core.Abstrations.Services;
using NavSat.Core.Tests;
using NavSat.Core.Abstrations.Models;
using Microsoft.OpenApi.Models;


[Route("api/[controller]")]
[ApiController]

    public class SatelliteData
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Position Position { get; set; }
        public Velocity Velocity { get; set; }
        public DateTime Timestamp { get; set; }
        public string Orbit { get; set; }
        public string Mission { get; set; }
        public string Country { get; set; }
    }

    public class Position
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double Altitude { get; set; }
    }

    public class Velocity
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }
    }
