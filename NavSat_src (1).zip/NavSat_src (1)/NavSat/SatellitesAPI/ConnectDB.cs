using Microsoft.AspNetCore.Mvc;
using NavSat.Core.Services;
using NavSat.Core;
using NavSat.Core.Abstrations.Services;
//using NavSat.Core.Tests;
//using NavSat.Core.Abstrations.Models;
//using Microsoft.Data.SqlClient;

//[Route("api/[controller]")]
//[ApiController]
//public class Connectdb : ControllerBase


//// Retrieve the passwordless connection string from appsettings.json
//string connectionString = Configuration.GetConnectionString("AZURE_SQL_CONNECTIONSTRING");

//// Create a new SqlConnection instance
//using SqlConnection connection = new SqlConnection(connectionString);

//// Open the connection
//connection.Open();

// Perform database operations here