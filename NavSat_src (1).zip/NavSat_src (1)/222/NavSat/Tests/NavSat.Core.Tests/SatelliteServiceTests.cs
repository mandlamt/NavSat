//using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NavSat.Core.Abstrations.Models;
using NavSat.Core.Abstrations.Services;
using NavSat.Core.Services;
using Xunit;

//using Moq;
//using NavSat.Core.Abstrations.Models;
//using NavSat.Core.Abstrations.Services;
//using NavSat.Core.Services;
//using Xunit;

namespace NavSat.Core.Tests.Services
{
    public class SatelliteServiceTests
    {
        [Fact]
        public void CreateFrom_ValidSatelliteId_ReturnsSatellite()
        {
            // Arrange
            var mockConstellationService = new Mock<IConstellationService>();
            var expectedSatelliteId = 123;
          //  var expectedSystem = new Constellation { 100, "GPS" };
            var expectedSystem = new Constellation(100, "GPS");
            mockConstellationService
                .Setup(x => x.For(expectedSatelliteId))
                .Returns(expectedSystem);
            var satelliteService = new SatelliteService(mockConstellationService.Object);
            // Act
            var actualSatellite = satelliteService.CreateFrom(expectedSatelliteId);
            // Assert
            Assert.Equal(expectedSatelliteId, actualSatellite.SatelliteId);
            Assert.NotNull(actualSatellite);
            Assert.Equal(expectedSatelliteId, actualSatellite.SatelliteId);
            Assert.Equal(25, actualSatellite.Prn);
            Assert.Equal("GPS", actualSatellite.Prefix);
        }

        [Fact]
        public void CreateFrom_InvalidSatelliteId_ReturnsNull()
        {
            // Arrange
            var mockConstellationService = new Mock<IConstellationService>();
            var invalidSatelliteId = 999;
            mockConstellationService
                .Setup(x => x.For(invalidSatelliteId))
                .Returns((Constellation)null);

            var satelliteService = new SatelliteService(mockConstellationService.Object);

            // Act
            var actualSatellite = satelliteService.CreateFrom(invalidSatelliteId);

            // Assert
            Assert.Null(actualSatellite);
        }
    }
}